package org.javacream.training.jms.basic;
import javax.jms.Session;

import org.apache.activemq.artemis.jms.client.ActiveMQConnectionFactory;
import org.javacream.training.jms.BrokerConfiguration;


public class Producer {

	public static void main(String[] args) throws Exception{
		var connectionFactory = new ActiveMQConnectionFactory(BrokerConfiguration.brokerUrl);
		var connection = connectionFactory.createConnection(BrokerConfiguration.username, BrokerConfiguration.password);
		var session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		var queue = session.createQueue(BrokerConfiguration.queueName);
		var message = session.createTextMessage("Hello");
		var messageProducer = session.createProducer(queue);
		messageProducer.send(message);
		connection.close();
		connectionFactory.close();
		
	}

}
